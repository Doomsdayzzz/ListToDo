using System.Windows;
using System.Windows.Controls;

namespace ListToDo;

public partial class ToggleButtonComponent : UserControl{
    public static readonly DependencyProperty Is_CheckedProperty = DependencyProperty.Register(
        nameof(Is_Checked), typeof(bool), typeof(InputComponent), new PropertyMetadata(default(bool)));

    public bool Is_Checked {
        get { return (bool)GetValue(Is_CheckedProperty); }
        set { SetValue(Is_CheckedProperty, value);  }
    }
    public ToggleButtonComponent() {
        InitializeComponent();
        Loaded+=((sender, args) => {
            Is_Checked = true;
            Toggle1.IsChecked = Is_Checked;
        });
    }
}